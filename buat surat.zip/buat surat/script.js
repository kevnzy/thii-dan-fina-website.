// script.js

// Menyimpan referensi elemen navbar
const navbar = document.querySelector('.navbar');

// Menambahkan event listener untuk scroll
window.addEventListener('scroll', () => {
    if (window.scrollY > 50) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }
});

// Jenaka karakter
const jokes = {
    thii: [
        "Kenapa Thii membawa baju renang ke sekolah? Karena dia ingin belajar renang matematika!",
        "Apa yang dilakukan Thii saat dia lapar? Dia makan pizza!",
        "Apa yang dikatakan Thii saat dia melihat bintang? 'Keren sekali, bintang-bintang itu bersinar seperti lampu-lampu!'"
    ],
    fina: [
        "Kenapa Fina suka sekali dengan bulan September? Karena dia baru saja membeli sepatu baru!",
        "Apa yang dilakukan Fina saat dia jatuh dari sepeda? Dia belajar untuk tidak jatuh lagi!",
        "Apa yang Fina katakan saat dia menang dalam lomba balap? 'Ternyata latihan membuat kita lebih cepat!'"
    ]
};

function showJoke(character) {
    const jokeElement = document.getElementById(`${character}-joke`);
    const jokesList = jokes[character];
    const randomJoke = jokesList[Math.floor(Math.random() * jokesList.length)];
    jokeElement.textContent = randomJoke;
}

// script.js

document.querySelectorAll('button').forEach(button => {
    button.addEventListener('click', () => {
        button.style.backgroundColor = '#45a049'; // Ubah warna tombol saat diklik
        setTimeout(() => {
            button.style.backgroundColor = '#4CAF50'; // Kembalikan warna tombol setelah 0.3 detik
        }, 300);
    });
});
